import { MigrationInterface, QueryRunner } from "typeorm";

export class OfferChanges1684624088102 implements MigrationInterface {
    name = 'OfferChanges1684624088102'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TABLE "offer" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "isDeleted" boolean NOT NULL DEFAULT true, "price" integer NOT NULL, "validUntil" character varying NOT NULL, "isAccepted" boolean NOT NULL DEFAULT false, "rateId" uuid NOT NULL, "userId" uuid NOT NULL, CONSTRAINT "REL_7d003ded589e099549aab1458d" UNIQUE ("rateId"), CONSTRAINT "REL_e8100751be1076656606ae045e" UNIQUE ("userId"), CONSTRAINT "PK_57c6ae1abe49201919ef68de900" PRIMARY KEY ("id"))`);
        await queryRunner.query(`ALTER TABLE "rate" DROP COLUMN "rate"`);
        await queryRunner.query(`ALTER TABLE "currency" DROP COLUMN "price"`);
        await queryRunner.query(`ALTER TABLE "rate" ADD "ratePrice" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "rate" ADD "markupRatePrice" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "offer" ADD CONSTRAINT "FK_7d003ded589e099549aab1458dc" FOREIGN KEY ("rateId") REFERENCES "rate"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "offer" ADD CONSTRAINT "FK_e8100751be1076656606ae045e3" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "offer" DROP CONSTRAINT "FK_e8100751be1076656606ae045e3"`);
        await queryRunner.query(`ALTER TABLE "offer" DROP CONSTRAINT "FK_7d003ded589e099549aab1458dc"`);
        await queryRunner.query(`ALTER TABLE "rate" DROP COLUMN "markupRatePrice"`);
        await queryRunner.query(`ALTER TABLE "rate" DROP COLUMN "ratePrice"`);
        await queryRunner.query(`ALTER TABLE "currency" ADD "price" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "rate" ADD "rate" integer NOT NULL`);
        await queryRunner.query(`DROP TABLE "offer"`);
    }

}
